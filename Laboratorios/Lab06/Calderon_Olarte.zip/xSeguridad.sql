DROP ROLE Entrenador;
DROP ROLE Atleta;